#
# Cookbook Name:: ews_hello
# Recipe:: pre_install
#
# Copyright (c) 2016 Early Warning Services, LLC. All Rights Reserved.
#
# Internal use only. Confidential and proprietary.
# You may not disclose, copy or distribute this material for any
# purpose in any medium without the expressed written consent of
# Early Warning.

###########################
#
# Add online user if doesn't exist at compile time
#
############################
group node['ews_hello']['group'] do
  gid node['ews_hello']['gid']
end

# TODO: user resource
user node['ews_hello']['user'] do
  uid node['ews_hello']['userid']
  gid node['ews_hello']['gid']
  shell '/bin/bash'
end
###########################
####
#### Directory management Section
####
############################
directory node['ews_hello']['log_folder'] do
  owner node['ews_hello']['user']
  group node['ews_hello']['group']
  mode 0775
end
