name 'ews_hello'
maintainer 'DevOps Team'
maintainer_email 'hr@earlywarning.com'
license 'All rights reserved'
description 'Installs/Configures ews_hello, a showcase application'\
            ' used for training at ews'
long_description 'Installs/Configures ews_hello'

version '0.0.12'
